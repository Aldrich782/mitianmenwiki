import { useParams, Link, useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, MapPin, User, Scroll, Mountain as MountainIcon, Landmark, User as UserIcon } from 'lucide-react';
import { allSects } from '@/data/sects';
import { zixiaoLandmarks } from '@/data/landmarks';
import { CommentSection } from '@/components/CommentSection';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

const SectDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const sect = allSects.find(s => s.id === id);

  if (!sect) {
    return (
      <div className="min-h-screen flex items-center justify-center page-transition">
        <div className="text-center space-y-4">
          <h2 className="text-2xl font-bold">门派未找到</h2>
          <Button onClick={() => navigate('/')}>返回首页</Button>
        </div>
      </div>
    );
  }

  const isZixiao = sect.id === 'zixiao';
  const isShanhaixuan = sect.id === 'shanhaixuan';

  return (
    <div className={`min-h-screen bg-gradient-to-br ${
      isZixiao ? 'from-purple-950/30 via-amber-950/20 to-purple-950/30' : 
      isShanhaixuan ? 'from-blue-950/30 via-cyan-950/20 to-blue-950/30' :
      'from-background via-muted/30 to-background'
    } page-transition`}>
      {/* 顶部导航 */}
      <header className="border-b border-border/50 bg-card/30 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between gap-2">
            <Link to={sect.region === 'yunhan' ? '/yunhan' : '/rongzhou'}>
              <Button variant="ghost" className="gap-2 text-xs sm:text-sm px-2 sm:px-4">
                <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden xs:inline">返回列表</span>
                <span className="xs:hidden">返回</span>
              </Button>
            </Link>
            <h1 className={`text-base sm:text-xl md:text-2xl font-bold truncate ${
              isZixiao ? 'text-purple-400' : 
              isShanhaixuan ? 'text-cyan-400' :
              'text-primary'
            }`}>{sect.name}</h1>
            <div className="w-16 sm:w-24" />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="max-w-5xl mx-auto space-y-6 sm:space-y-8">
          {/* 门派简介 - 左侧图标，右侧文字 */}
          <Card className={`p-4 sm:p-6 md:p-8 bg-card/50 backdrop-blur-sm ${
            isZixiao ? 'border-purple-500/30' :
            isShanhaixuan ? 'border-cyan-500/30' :
            'border-border/50'
          } shadow-card`}>
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 items-start">
              {/* 左侧门派图标 */}
              <div className={`flex-shrink-0 w-20 h-20 sm:w-24 sm:h-24 md:w-32 md:h-32 rounded-xl bg-gradient-to-br ${isZixiao ? 'from-purple-500/20 to-amber-500/20' : 'from-primary/20 to-accent/20'} flex items-center justify-center mx-auto sm:mx-0`}>
                <Scroll className={`w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 ${isZixiao ? 'text-amber-400/60' : 'text-primary/60'}`} />
              </div>
              
              {/* 右侧简介 */}
              <div className="flex-1 space-y-3 sm:space-y-4">
                <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
                  门派简介
                </h2>
                <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
                  {sect.description}
                </p>
                {sect.specialty && (
                  <div className={`p-3 rounded-lg ${isZixiao ? 'bg-purple-500/5 border border-purple-500/20' : 'bg-primary/5 border border-primary/20'}`}>
                    <p className="text-xs sm:text-sm text-foreground">
                      <span className={`font-semibold ${isZixiao ? 'text-purple-400' : 'text-primary'}`}>门派特色：</span>
                      {sect.specialty}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </Card>

          {/* 门派结构 - 六山峰或各分支 */}
          {isZixiao && sect.mountains ? (
            <>
              {/* 紫霄宗六山峰 */}
              <Card className="p-8 bg-card/50 backdrop-blur-sm border-purple-500/30 shadow-card">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <MountainIcon className="w-6 h-6 text-purple-400" />
                    门派结构 · 六山峰
                  </h2>
                  <Link to="/characters">
                    <Button variant="outline" size="sm" className="text-xs">
                      查看所有重要人物 →
                    </Button>
                  </Link>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
                  {sect.mountains.map((mountain) => (
                    <Link key={mountain.id} to={`/mountain/${mountain.id}`}>
                      <Card className="group p-4 sm:p-6 bg-gradient-to-br from-purple-500/5 to-amber-500/5 border-purple-500/30 hover:border-amber-500/50 transition-all duration-300 hover:shadow-soft hover:-translate-y-1 cursor-pointer">
                        <h3 className="text-base sm:text-lg md:text-xl font-semibold mb-2 group-hover:text-amber-400 transition-colors">
                          {mountain.name}
                        </h3>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2">
                          {mountain.description}
                        </p>
                        <div className="mt-3 sm:mt-4 text-xs sm:text-sm text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity">
                          查看详情 →
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </Card>
            </>
          ) : sect.divisions && sect.divisions.length > 0 ? (
            <>
              {/* 其他门派的分支结构 */}
              <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
                isShanhaixuan ? 'border-cyan-500/30' : 'border-border/50'
              } shadow-card`}>
                <div className="flex items-center justify-between mb-6">
                  <h2 className={`text-2xl font-bold flex items-center gap-2 ${
                    isShanhaixuan ? 'text-cyan-400' : ''
                  }`}>
                    <MountainIcon className={`w-6 h-6 ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`} />
                    门派结构
                  </h2>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
                  {sect.divisions.map((division) => (
                    <Link key={division.id} to={`/division/${sect.id}/${division.id}`}>
                      <Card className={`group p-4 sm:p-6 bg-gradient-to-br ${
                        isShanhaixuan ? 'from-cyan-500/5 to-blue-500/5 border-cyan-500/30 hover:border-blue-500/50' :
                        'from-primary/5 to-accent/5 border-border/30 hover:border-primary/50'
                      } transition-all duration-300 hover:shadow-soft hover:-translate-y-1 cursor-pointer`}>
                        <h3 className={`text-base sm:text-lg md:text-xl font-semibold mb-2 group-hover:${
                          isShanhaixuan ? 'text-blue-400' : 'text-primary'
                        } transition-colors`}>
                          {division.name}
                        </h3>
                        <p className="text-xs sm:text-sm text-muted-foreground line-clamp-2">
                          {division.description}
                        </p>
                        <div className={`mt-3 sm:mt-4 text-xs sm:text-sm opacity-0 group-hover:opacity-100 transition-opacity ${
                          isShanhaixuan ? 'text-blue-400' : 'text-primary'
                        }`}>
                          查看详情 →
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </Card>
            </>
          ) : (
            <>
              {/* 其他门派：掌门 */}
              <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
                isShanhaixuan ? 'border-cyan-500/30' : 'border-border/50'
              } shadow-card`}>
                <h2 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${
                  isShanhaixuan ? 'text-cyan-400' : ''
                }`}>
                  <User className={`w-6 h-6 ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`} />
                  掌门
                </h2>
                <div className="text-lg">
                  <span className={`font-semibold ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`}>{sect.leader}</span>
                </div>
              </Card>

              {/* 重要人物 */}
              {sect.members && sect.members.length > 0 && (
                <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
                  isShanhaixuan ? 'border-cyan-500/30' : 'border-border/50'
                } shadow-card`}>
                  <h2 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${
                    isShanhaixuan ? 'text-cyan-400' : ''
                  }`}>
                    <User className={`w-6 h-6 ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`} />
                    重要人物
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    {sect.members.map((member) => (
                      <Link key={member.id} to={`/character/${member.id}`}>
                        <Card 
                          className={`group p-4 sm:p-6 bg-gradient-to-br ${
                            isShanhaixuan ? 'from-cyan-500/5 to-blue-500/5 border-cyan-500/30 hover:border-cyan-500/50' : 
                            'from-primary/5 to-accent/5 border-border/30 hover:border-primary/50'
                          } hover:shadow-soft hover:-translate-y-1 transition-all duration-300 cursor-pointer`}
                        >
                          <div className="flex gap-4">
                            {/* 头像 */}
                            <div className="flex-shrink-0">
                              <Avatar className={`w-16 h-16 sm:w-20 sm:h-20 border-2 ${
                                isShanhaixuan ? 'border-cyan-500/30' : 'border-primary/30'
                              }`}>
                                {member.avatar && (
                                  <AvatarImage src={member.avatar} alt={member.name} />
                                )}
                                <AvatarFallback className={`${
                                  isShanhaixuan ? 'bg-cyan-500/10 text-cyan-400' : 'bg-primary/10 text-primary'
                                }`}>
                                  <UserIcon className="w-8 h-8" />
                                </AvatarFallback>
                              </Avatar>
                            </div>

                            {/* 信息 */}
                            <div className="flex-1 min-w-0">
                              <h3 className={`text-lg sm:text-xl font-bold mb-1 ${
                                isShanhaixuan ? 'text-cyan-400 group-hover:text-cyan-300' : 'text-foreground group-hover:text-primary'
                              } transition-colors`}>{member.name}</h3>
                              <p className={`text-xs sm:text-sm mb-2 ${
                                isShanhaixuan ? 'text-cyan-300/70' : 'text-primary'
                              }`}>{member.title}</p>
                              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed line-clamp-2">{member.description}</p>
                              {member.specialty && (
                                <div className={`mt-3 pt-3 border-t ${
                                  isShanhaixuan ? 'border-cyan-500/20' : 'border-border/30'
                                }`}>
                                  <p className="text-xs text-muted-foreground">
                                    专长：<span className="text-foreground">{member.specialty}</span>
                                  </p>
                                </div>
                              )}
                              <div className={`mt-2 text-xs opacity-0 group-hover:opacity-100 transition-opacity ${
                                isShanhaixuan ? 'text-cyan-400' : 'text-primary'
                              }`}>
                                查看详情 →
                              </div>
                            </div>
                          </div>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </Card>
              )}

              {/* 地理位置 */}
              <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
                isShanhaixuan ? 'border-cyan-500/30' : 'border-border/50'
              } shadow-card`}>
                <h2 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${
                  isShanhaixuan ? 'text-cyan-400' : ''
                }`}>
                  <MapPin className={`w-6 h-6 ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`} />
                  地理位置
                </h2>
                <p className="text-muted-foreground text-lg">{sect.location}</p>
              </Card>

              {/* 门规 */}
              <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
                isShanhaixuan ? 'border-cyan-500/30' : 'border-border/50'
              } shadow-card`}>
                <h2 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${
                  isShanhaixuan ? 'text-cyan-400' : ''
                }`}>
                  <Scroll className={`w-6 h-6 ${isShanhaixuan ? 'text-cyan-400' : 'text-primary'}`} />
                  门规
                </h2>
                <ul className="space-y-3">
                  {sect.rules.map((rule, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <span className={`flex-shrink-0 w-6 h-6 rounded-full ${
                        isShanhaixuan ? 'bg-cyan-500/10 text-cyan-400' : 'bg-primary/10 text-primary'
                      } flex items-center justify-center text-sm font-medium mt-0.5`}>
                        {index + 1}
                      </span>
                      <span className="text-muted-foreground flex-1">{rule}</span>
                    </li>
                  ))}
                </ul>
              </Card>
            </>
          )}

          {/* 地标建筑 */}
          {sect.landmarks && sect.landmarks.length > 0 && (
            <Card className={`p-8 bg-card/50 backdrop-blur-sm ${
              isZixiao ? 'border-purple-500/30' :
              isShanhaixuan ? 'border-cyan-500/30' :
              'border-border/50'
            } shadow-card`}>
              <h2 className={`text-2xl font-bold mb-6 flex items-center gap-2 ${
                isZixiao ? 'text-purple-400' :
                isShanhaixuan ? 'text-cyan-400' : ''
              }`}>
                <Landmark className={`w-6 h-6 ${
                  isZixiao ? 'text-purple-400' :
                  isShanhaixuan ? 'text-cyan-400' :
                  'text-primary'
                }`} />
                {isZixiao ? '地标建筑' : '重要地标'}
              </h2>
              {isZixiao ? (
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {zixiaoLandmarks.map((landmark) => (
                    <Link key={landmark.id} to={`/landmark/${landmark.id}`}>
                      <Card className="group overflow-hidden bg-gradient-to-br from-purple-500/5 to-amber-500/5 border-purple-500/30 hover:border-amber-500/50 transition-all duration-300 hover:shadow-soft hover:-translate-y-1 cursor-pointer">
                        {/* 缩略图 */}
                        <div className="aspect-video bg-gradient-to-br from-purple-500/10 to-amber-500/10 flex items-center justify-center">
                          {landmark.thumbnail ? (
                            <img 
                              src={landmark.thumbnail} 
                              alt={landmark.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <MapPin className="w-8 h-8 text-amber-400/40" />
                          )}
                        </div>
                        
                        {/* 信息 */}
                        <div className="p-4 space-y-2">
                          <h3 className="text-base font-semibold group-hover:text-amber-400 transition-colors">
                            {landmark.name}
                          </h3>
                          <p className="text-xs text-muted-foreground line-clamp-1">
                            {landmark.nickname}
                          </p>
                          <div className="text-xs text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity">
                            查看详情 →
                          </div>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-4">
                  {sect.landmarks.map((landmark) => (
                    <Card 
                      key={landmark.id} 
                      className={`p-6 bg-gradient-to-br ${
                        isShanhaixuan ? 'from-cyan-500/5 to-blue-500/5 border-cyan-500/30' : 'from-primary/5 to-accent/5 border-border/30'
                      } hover:shadow-soft transition-all duration-300`}
                    >
                      <h3 className={`text-xl font-bold mb-2 ${
                        isShanhaixuan ? 'text-cyan-400' : 'text-foreground'
                      }`}>{landmark.name}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{landmark.description}</p>
                      <div className={`mt-3 pt-3 border-t ${
                        isShanhaixuan ? 'border-cyan-500/20' : 'border-border/30'
                      }`}>
                        <p className="text-xs text-muted-foreground">
                          类型：<span className="text-foreground">{
                            landmark.type === 'mountain' ? '山脉' :
                            landmark.type === 'river' ? '河流' :
                            landmark.type === 'forest' ? '森林' :
                            landmark.type === 'sea' ? '海域' :
                            '其他'
                          }</span>
                        </p>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </Card>
          )}

          {/* 评论区 */}
          <CommentSection pageType="sect" pageId={id || ''} />
        </div>
      </main>
    </div>
  );
};

export default SectDetail;
